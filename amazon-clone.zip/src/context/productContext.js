import {createContext} from "react";

const productContext = createContext({});

export default productContext