import {createContext} from "react";

const  storeDataContext = createContext();

export default storeDataContext