import {createContext} from "react";

const  categoryContext = createContext({});

export default categoryContext