import {createContext} from "react";

const  storeProductContext = createContext();

export default storeProductContext